const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.redirect('/api/servicio');
});

app.get('/api/servicio', (req, res) => {
    res.send('servicios unach');
});

app.listen(3001, () => {
    console.log(`Servidor corriendo en http://localhost:3001/api/servicio`);
});